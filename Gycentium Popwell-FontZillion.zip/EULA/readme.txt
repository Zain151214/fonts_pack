[GCD15]

Gycentium Popwell.ttf is a pop style of Rockwell(typeface).
Addapted from Rockwell(typeface) which was designed at the Monotype foundry's in-house design studio in 1934.

This font is made as a tribute to Gycentium Credas Disorator, 15th generation of MAN ICS.

This font is free for personal use.
For commercial use, please mail to:

callmetwentynine@gmail.com



Best regard,