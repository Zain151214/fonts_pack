SANS SARA
A Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

This is the initial release of a font with several future releases and related fonts planned. SANS SARA is an all-new Bauhaus-styled font modeled on two things: the style Herbert Bayer, and the style, writing, and even personality of Sara King, a woman my wife and I love very much. This release, finalized and released on Sara's birthday, is a tribute to her, one of many to come. The many playful and symbolic connections between Sara King and Herbert Bayer will be documented in a special PDF to be included with later releases ... but for now suffice it to say that every detail of the font is symbolic in some way.

This font is copyright � 2011 by S. John Ross. "Cumberland Games & Diversions" and this font's title are trademarks of S. John Ross. This font is free for private use only. Any public or commercial use, or any use by an organization rather than an individual, requires a license; contact the Cumberland Fontworks via email (sjohn@cumberlandgames.com) or find me on the Web for additional contact information. Additional glyphs (foreign alphabet support, customizations, etc) are available by commission.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0
http://fonts.cumberlandgames.com
http://private-use.cumberlandgames.com